// Quibly App Shell
const { useState: useStateApp, useEffect: useEffectApp } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "screen": "menu",
  "popup": "none",
  "scene": "phone"
}/*EDITMODE-END*/;

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [screen, setScreen] = useStateApp(tweaks.screen || 'menu');
  const [popup, setPopup] = useStateApp(tweaks.popup || 'none');
  const [scene, setScene] = useStateApp(tweaks.scene || 'phone');

  useEffectApp(() => { if (tweaks.screen) setScreen(tweaks.screen); }, [tweaks.screen]);
  useEffectApp(() => { if (tweaks.popup) setPopup(tweaks.popup); }, [tweaks.popup]);
  useEffectApp(() => { if (tweaks.scene) setScene(tweaks.scene); }, [tweaks.scene]);

  const [state, setState] = useStateApp({ coins: 285, bestScore: 1204, streak: 7 });

  const go = (s) => { setScreen(s); setTweak('screen', s); setPopup('none'); setTweak('popup', 'none'); };
  const openModal = (m) => { setPopup(m); setTweak('popup', m); };
  const closeModal = () => { setPopup('none'); setTweak('popup', 'none'); };

  const screens = {
    menu: <MenuScreen go={go} state={state} setState={setState} openModal={openModal} />,
    game: <GameScreen go={go} state={state} setState={setState} openModal={openModal} />,
    shop: <ShopScreen go={go} state={state} setState={setState} openModal={openModal} />,
    modes: <ModesScreen go={go} state={state} setState={setState} openModal={openModal} />,
    settings: <SettingsScreen go={go} state={state} setState={setState} />,
  };

  const popups = {
    gameover: <PopupGameOver onClose={closeModal} onPlayAgain={() => { closeModal(); go('game'); }} score={state.bestScore + 142} />,
    cleared: <PopupBoardCleared onClose={closeModal} />,
    buy: <PopupBuyCharge onClose={closeModal} />,
    daily: <PopupDailyReward onClose={closeModal} />,
    quests: <PopupQuests onClose={closeModal} />,
    pause: <PopupPause onClose={closeModal} onMenu={() => { closeModal(); go('menu'); }} onRestart={closeModal} />,
    profile: <PopupProfile onClose={closeModal} />,
    locked: <PopupLocked onClose={closeModal} />,
  };

  // Gallery scene: show all popups in a grid
  if (scene === 'gallery') {
    return (
      <div style={{ minHeight: '100vh', background: 'linear-gradient(180deg,#1a1530,#3b2d5e)', padding: 30 }}>
        <div style={{ textAlign: 'center', color: 'white', fontFamily: 'Fredoka', fontSize: 28, marginBottom: 20 }}>Pop-up Gallery</div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: 20 }}>
          {Object.keys(popups).map(k => (
            <div key={k} style={{ position: 'relative', height: 720, borderRadius: 36, overflow: 'hidden', background: '#000' }}>
              <div style={{ position: 'absolute', inset: 0 }}>
                <MenuScreen go={() => {}} state={state} setState={setState} openModal={() => {}} />
              </div>
              {popups[k]}
              <div style={{ position: 'absolute', top: 8, left: 8, padding: '4px 10px', borderRadius: 999, background: 'rgba(0,0,0,0.6)', color: 'white', fontFamily: 'Fredoka', fontSize: 12, zIndex: 100 }}>{k}</div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Phone scene: single iPhone frame
  return (
    <div style={{ minHeight: '100vh', background: 'radial-gradient(ellipse at center, #2c1f55, #14102a)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <IOSDevice width={390} height={844} dark={true}>
        <div style={{ position: 'absolute', inset: 0, background: '#000' }} data-screen-label={screen}>
          {screens[screen]}
          {popups[popup] || null}
        </div>
      </IOSDevice>

      <TweaksPanel title="Tweaks">
        <TweakSection title="Scene">
          <TweakRadio value={scene} onChange={(v) => { setScene(v); setTweak('scene', v); }} options={[
            { value: 'phone', label: 'Phone' },
            { value: 'gallery', label: 'Pop-up Gallery' },
          ]} />
        </TweakSection>
        <TweakSection title="Screen">
          <TweakSelect value={screen} onChange={(v) => go(v)} options={[
            { value: 'menu', label: 'Menu' },
            { value: 'game', label: 'Game' },
            { value: 'shop', label: 'Shop' },
            { value: 'modes', label: 'Modes' },
            { value: 'settings', label: 'Settings' },
          ]} />
        </TweakSection>
        <TweakSection title="Pop-up">
          <TweakSelect value={popup} onChange={(v) => { setPopup(v); setTweak('popup', v); }} options={[
            { value: 'none', label: 'None' },
            { value: 'gameover', label: 'Game Over' },
            { value: 'cleared', label: 'Board Cleared' },
            { value: 'buy', label: 'Buy Charge' },
            { value: 'daily', label: 'Daily Reward' },
            { value: 'quests', label: 'Quests' },
            { value: 'pause', label: 'Pause' },
            { value: 'profile', label: 'Profile' },
            { value: 'locked', label: 'Locked Feature' },
          ]} />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);

// Quibly Shop Screen
function ShopScreen({ go, state, setState, openModal }) {
  const powerUps = [
    { id: 'hint', icon: <Icon.Hint s={26} c="#fff" />, name: 'Hint', desc: 'Reveals a pending word match', cost: 25, owned: 2, tint: 'linear-gradient(180deg,#ffe27a,#ffb83a)' },
    { id: 'shuffle', icon: <Icon.Shuffle s={26} c="#fff" />, name: 'Shuffle', desc: 'Randomly rearranges all tiles', cost: 50, owned: 1, tint: 'linear-gradient(180deg,#9ad4ff,#3398ff)' },
    { id: 'wild', icon: <Icon.Wild s={26} c="#fff" />, name: 'Wild', desc: 'Converts any tile into a joker', cost: 60, owned: 1, tint: 'linear-gradient(180deg,#d6b6ff,#8c5ce5)' },
    { id: 'bomb', icon: <Icon.Bomb s={26} c="#fff" />, name: 'Bomb', desc: 'Clears a full row and column', cost: 75, owned: 1, tint: 'linear-gradient(180deg,#ff9d8a,#ff5a44)' },
  ];

  const coinPacks = [
    { amount: 100, label: 'Starter', tint: 'linear-gradient(180deg, #d8edff, #9ec9ff)', accent: '#3a78c2' },
    { amount: 300, label: 'Builder', tint: 'linear-gradient(180deg, #d6f8d8, #8ce29c)', accent: '#1f9d5b', popular: true },
    { amount: 750, label: 'Master',  tint: 'linear-gradient(180deg, #fff1c4, #ffcf6a)', accent: '#a76b00' },
  ];

  return (
    <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, #ede4ff 0%, #ffe1ec 60%, #fff1d8 100%)' }}>
      <Sparkles count={10} />
      {/* Header */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '48px 16px 16px', background: 'linear-gradient(180deg, rgba(255,255,255,0.4), transparent)', backdropFilter: 'blur(6px)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <CircleBtn size={40} onClick={() => go('menu')}><Icon.Back s={18} c="#3a2a78" /></CircleBtn>
          <div style={{
            fontFamily: 'Fredoka', fontWeight: 600, fontSize: 22, color: '#3a2a78',
            display: 'inline-flex', alignItems: 'center', gap: 8,
          }}>
            <Icon.Cart s={20} c="#3a2a78" /> Shop
          </div>
          <CoinChip amount={state.coins} big />
        </div>
      </div>

      {/* Scrollable content */}
      <div className="scrollable" style={{ position: 'absolute', top: 110, bottom: 0, left: 0, right: 0, padding: '6px 16px 30px' }}>
        {/* Hero pack */}
        <div style={{
          marginTop: 8,
          borderRadius: 24, padding: 16,
          background: 'linear-gradient(135deg, #b39bff 0%, #ff7cb6 60%, #ffd97a 100%)',
          color: 'white',
          position: 'relative', overflow: 'hidden',
          boxShadow: 'inset 0 -5px 0 rgba(80, 30, 130, 0.4), 0 6px 0 rgba(80, 30, 130, 0.25)',
        }}>
          <Sparkles count={8} />
          <div style={{ position: 'absolute', top: -10, right: -10, width: 100, height: 100, background: 'radial-gradient(circle, rgba(255,255,255,0.5), transparent 70%)' }} />
          <div style={{ position: 'relative' }}>
            <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 11, letterSpacing: 1, opacity: 0.9 }}>LIMITED · 48H</div>
            <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 26, lineHeight: 1.05, marginTop: 4, textShadow: '0 2px 0 rgba(80, 30, 130, 0.45)' }}>Sparkle Bundle</div>
            <div style={{ fontFamily: 'Nunito', fontWeight: 700, fontSize: 12, opacity: 0.95, marginTop: 4 }}>1,500 coins · 5 of every power-up · Sunset theme</div>
            <div style={{ display: 'flex', gap: 12, marginTop: 12, alignItems: 'center' }}>
              <div style={{
                padding: '8px 14px', borderRadius: 999,
                background: 'white', color: '#a83d6e', fontFamily: 'Fredoka', fontWeight: 600, fontSize: 16,
                boxShadow: 'inset 0 -3px 0 rgba(180, 50, 110, 0.3), 0 3px 0 rgba(180, 50, 110, 0.3)',
              }}>$4.99</div>
              <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 12, opacity: 0.9, textDecoration: 'line-through' }}>$9.99</div>
              <div style={{ marginLeft: 'auto', fontFamily: 'Fredoka', fontWeight: 600, fontSize: 12, padding: '4px 10px', borderRadius: 999, background: 'rgba(255,255,255,0.25)', backdropFilter: 'blur(4px)' }}>−50%</div>
            </div>
          </div>
        </div>

        {/* Power-Ups */}
        <SectionHeader title="Power-Ups" subtitle="Spend coins for extra charges" />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {powerUps.map(p => (
            <div key={p.id} className="q-card" style={{ padding: 12, display: 'flex', alignItems: 'center', gap: 12, borderRadius: 20 }}>
              <div style={{
                width: 56, height: 56, borderRadius: 18,
                background: p.tint,
                display: 'grid', placeItems: 'center',
                boxShadow: 'inset 0 -3px 0 rgba(60, 30, 120, 0.3), 0 3px 0 rgba(60, 30, 120, 0.2)',
              }}>{p.icon}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
                  <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 17, color: '#3a2a78' }}>{p.name}</div>
                  <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 12, color: 'rgba(58,42,120,0.55)' }}>×{p.owned} owned</div>
                </div>
                <div style={{ fontFamily: 'Nunito', fontWeight: 600, fontSize: 12, color: 'rgba(58,42,120,0.7)' }}>{p.desc}</div>
              </div>
              <button style={{
                border: 'none', cursor: 'pointer',
                padding: '8px 12px', borderRadius: 999,
                background: 'linear-gradient(180deg, #fff8da, #ffe39a)',
                color: '#7a4500',
                fontFamily: 'Fredoka', fontWeight: 600, fontSize: 14,
                boxShadow: 'inset 0 -3px 0 rgba(180, 110, 0, 0.35), 0 3px 0 rgba(180, 110, 0, 0.3)',
                display: 'inline-flex', alignItems: 'center', gap: 5,
              }}>
                <span style={{ width: 14, height: 14, borderRadius: '50%', background: 'radial-gradient(circle at 30% 25%, #fff5b3, #f0a420 70%)', display: 'inline-block' }} />
                {p.cost}
              </button>
            </div>
          ))}
        </div>

        {/* Coin Packs */}
        <SectionHeader title="Coin Packs" subtitle="Free — no purchase required" />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
          {coinPacks.map(p => (
            <div key={p.amount} style={{
              borderRadius: 18,
              background: p.tint,
              padding: 12,
              boxShadow: 'inset 0 -4px 0 rgba(80, 50, 160, 0.18), inset 0 1px 0 rgba(255,255,255,0.85), 0 4px 0 rgba(80, 50, 160, 0.18)',
              textAlign: 'center', position: 'relative',
            }}>
              {p.popular && (
                <div style={{
                  position: 'absolute', top: -8, left: '50%', transform: 'translateX(-50%)',
                  background: '#ff7cb6', color: 'white',
                  fontFamily: 'Fredoka', fontWeight: 600, fontSize: 9,
                  padding: '2px 8px', borderRadius: 999,
                  boxShadow: '0 2px 0 rgba(160, 30, 90, 0.4)',
                  whiteSpace: 'nowrap',
                }}>BEST VALUE</div>
              )}
              <div style={{
                width: 36, height: 36, borderRadius: '50%', margin: '6px auto 4px',
                background: 'radial-gradient(circle at 30% 25%, #fff5b3, #f0a420 70%)',
                boxShadow: 'inset -2px -3px 0 rgba(140, 80, 0, 0.4)',
                animation: 'coin-bob 2.4s ease-in-out infinite',
              }} />
              <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 18, color: p.accent }}>+{p.amount}</div>
              <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 10, color: 'rgba(58,42,120,0.65)', textTransform: 'uppercase', letterSpacing: 0.6 }}>{p.label}</div>
              <button style={{
                marginTop: 6,
                border: 'none', cursor: 'pointer',
                padding: '4px 12px', borderRadius: 999,
                background: '#36c071', color: 'white',
                fontFamily: 'Fredoka', fontWeight: 600, fontSize: 11,
                boxShadow: 'inset 0 -2px 0 rgba(20, 100, 50, 0.4), 0 2px 0 rgba(20, 100, 50, 0.3)',
              }}>FREE</button>
            </div>
          ))}
        </div>

        {/* Themes */}
        <SectionHeader title="Tile Themes" subtitle="Re-skin your board" />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
          <ThemeCard name="Cream" letters={['Q','U']} bg="linear-gradient(180deg, #fffaf0, #ffe9c8)" color="#3a2a78" cost={0} owned />
          <ThemeCard name="Mint" letters={['Q','U']} bg="linear-gradient(180deg, #d6f8d8, #8ce29c)" color="#1f6d3b" cost={400} />
          <ThemeCard name="Galaxy" letters={['Q','U']} bg="linear-gradient(180deg, #5a3aa3, #2b1d63)" color="#fff8b3" cost={800} />
          <ThemeCard name="Bubble" letters={['Q','U']} bg="linear-gradient(180deg, #ffd5ea, #ff9bc8)" color="#a83d6e" cost={400} />
          <ThemeCard name="Lemonade" letters={['Q','U']} bg="linear-gradient(180deg, #fff7b3, #ffd54a)" color="#a76b00" cost={500} />
          <ThemeCard name="Sky" letters={['Q','U']} bg="linear-gradient(180deg, #cceaff, #7fbcff)" color="#1d558d" cost={500} locked />
        </div>

        <div style={{ textAlign: 'center', marginTop: 18, fontFamily: 'Nunito', fontWeight: 700, fontSize: 11, color: 'rgba(58,42,120,0.55)' }}>
          Coin packs are free — no purchase required.
        </div>
      </div>
    </div>
  );
}

function SectionHeader({ title, subtitle }) {
  return (
    <div style={{ margin: '20px 2px 10px' }}>
      <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 18, color: '#3a2a78' }}>{title}</div>
      <div style={{ fontFamily: 'Nunito', fontWeight: 700, fontSize: 11, color: 'rgba(58,42,120,0.6)' }}>{subtitle}</div>
    </div>
  );
}

function ThemeCard({ name, letters, bg, color, cost, owned, locked }) {
  return (
    <div style={{
      borderRadius: 18,
      background: 'rgba(255,255,255,0.55)', backdropFilter: 'blur(8px)',
      padding: 10, textAlign: 'center',
      boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.85), 0 3px 0 rgba(80, 50, 160, 0.15)',
      position: 'relative',
    }}>
      <div style={{ display: 'flex', justifyContent: 'center', gap: 4 }}>
        {letters.map((L, i) => (
          <div key={i} style={{
            width: 28, height: 28, borderRadius: 8,
            background: bg, color, fontFamily: 'Fredoka', fontWeight: 600, fontSize: 16,
            display: 'grid', placeItems: 'center',
            boxShadow: 'inset 0 -2px 0 rgba(80,50,160,0.18), 0 2px 0 rgba(80,50,160,0.18)',
            opacity: locked ? 0.55 : 1,
          }}>{L}</div>
        ))}
      </div>
      <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 13, color: '#3a2a78', marginTop: 6 }}>{name}</div>
      {owned ? (
        <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 11, color: '#1f9d5b' }}>EQUIPPED</div>
      ) : locked ? (
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontFamily: 'Fredoka', fontWeight: 600, fontSize: 11, color: 'rgba(58,42,120,0.6)' }}>
          <Icon.Lock s={11} c="#6a59a8" /> Lvl 20
        </div>
      ) : (
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 3, fontFamily: 'Fredoka', fontWeight: 600, fontSize: 11, color: '#7a4500' }}>
          <span style={{ width: 10, height: 10, borderRadius: '50%', background: 'radial-gradient(circle at 30% 25%, #fff5b3, #f0a420 70%)', display: 'inline-block' }} />
          {cost}
        </div>
      )}
    </div>
  );
}

window.ShopScreen = ShopScreen;

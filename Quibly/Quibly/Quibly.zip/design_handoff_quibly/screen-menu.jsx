// Quibly Menu Screen
const { useState: useStateMenu } = React;

function MenuScreen({ go, state, setState, openModal }) {
  const previewLetters = [
    ['Q','U','I','B'],
    ['L','P','A','R'],
    ['E','L','A','Y'],
    ['W','O','R','D'],
  ];
  const isHL = (r,c) => (r===1 && c===1) || (r===2 && c>=1 && c<=3);

  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <DreamBackground>
        {/* Top bar */}
        <div style={{
          position: 'absolute', top: 56, left: 16, right: 16,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <button onClick={() => openModal('profile')} style={{
            border: 'none', padding: 0, background: 'transparent', cursor: 'pointer',
            display: 'flex', alignItems: 'center', gap: 8,
          }}>
            <div style={{
              width: 40, height: 40, borderRadius: '50%',
              background: 'linear-gradient(135deg, #ffd5ea, #b39bff)',
              boxShadow: 'inset 0 -3px 0 rgba(80, 50, 160, 0.35), 0 3px 0 rgba(80, 50, 160, 0.3)',
              display: 'grid', placeItems: 'center',
              fontFamily: 'Fredoka', fontWeight: 600, color: 'white', fontSize: 18,
              textShadow: '0 1px 0 rgba(80, 50, 160, 0.4)',
            }}>R</div>
            <div style={{ textAlign: 'left' }}>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.85)', fontFamily: 'Nunito', fontWeight: 700, letterSpacing: 0.6, textTransform: 'uppercase' }}>Lvl 12</div>
              <div style={{ fontSize: 14, color: 'white', fontFamily: 'Fredoka', fontWeight: 600, textShadow: '0 1px 0 rgba(80, 50, 160, 0.4)' }}>Riley</div>
            </div>
          </button>

          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => openModal('daily')} style={{
              position: 'relative',
              padding: '6px 12px', border: 'none', cursor: 'pointer',
              background: 'linear-gradient(180deg, #ffb3d9, #ff6fae)',
              borderRadius: 999, color: 'white',
              fontFamily: 'Fredoka', fontWeight: 600, fontSize: 13,
              boxShadow: 'inset 0 -3px 0 rgba(160, 30, 90, 0.4), inset 0 1px 0 rgba(255,255,255,0.55), 0 3px 0 rgba(160, 30, 90, 0.3)',
              display: 'inline-flex', alignItems: 'center', gap: 6,
              textShadow: '0 1px 0 rgba(160, 30, 90, 0.4)',
            }}>
              <Icon.Gift s={16} c="#fff" />
              Daily
              <span style={{
                position: 'absolute', top: -4, right: -4,
                background: '#ffc23d', color: '#7a4500',
                borderRadius: '50%', width: 18, height: 18,
                fontSize: 11, fontWeight: 700, fontFamily: 'Fredoka',
                display: 'grid', placeItems: 'center',
                boxShadow: '0 2px 0 rgba(180,110,0,0.4)',
                textShadow: 'none',
              }}>3</span>
            </button>
            <CircleBtn size={36} onClick={() => go('settings')}>
              <Icon.Cog s={18} c="#3a2a78" />
            </CircleBtn>
          </div>
        </div>

        {/* Logo */}
        <div style={{ position: 'absolute', top: 130, left: 0, right: 0, textAlign: 'center' }}>
          <div style={{ animation: 'float-y 4s ease-in-out infinite', '--rot': '-2deg' }}>
            <QuiblyLogo size={68} />
          </div>
          <div style={{
            marginTop: 4,
            fontFamily: 'Fredoka', fontSize: 13, fontWeight: 500,
            color: 'rgba(255,255,255,0.95)',
            textShadow: '0 1px 0 rgba(80,50,160,0.4)',
          }}>Slide. Spell. Sparkle.</div>
        </div>

        {/* Floating tiles around logo */}
        <div style={{ position: 'absolute', top: 118, left: 12, animation: 'float-y 3.4s ease-in-out infinite', '--rot': '-12deg', transform: 'rotate(-12deg)' }}>
          <Tile letter="Q" size={42} />
        </div>
        <div style={{ position: 'absolute', top: 184, right: 18, animation: 'float-y 4.1s ease-in-out infinite', '--rot': '14deg', transform: 'rotate(14deg)' }}>
          <Tile letter="B" size={38} />
        </div>
        <div style={{ position: 'absolute', top: 230, left: 18, animation: 'float-y 3.8s ease-in-out infinite', '--rot': '8deg', transform: 'rotate(8deg)' }}>
          <Tile letter="Y" size={34} />
        </div>

        {/* Stats row */}
        <div style={{
          position: 'absolute', top: 260, left: 24, right: 24,
          display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8,
        }}>
          <StatChip icon={<Icon.Trophy s={16} c="#7a4500" />} label="Best" value={state.bestScore} bg="linear-gradient(180deg,#fff5d4,#ffd97a)" />
          <StatChip icon={<Icon.Flame s={16} c="#a83d00" />} label="Streak" value={`${state.streak}d`} bg="linear-gradient(180deg,#ffd9c4,#ffa97a)" />
          <StatChip icon={<span style={{ width: 14, height: 14, borderRadius: '50%', background: 'radial-gradient(circle at 30% 25%, #fff5b3, #f0a420 70%)', display:'inline-block' }} />} label="Coins" value={state.coins} bg="linear-gradient(180deg,#fff8da,#ffe39a)" />
        </div>

        {/* Board preview */}
        <div style={{ position: 'absolute', top: 324, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
          <div className="q-card" style={{
            padding: 10, borderRadius: 28,
            background: 'rgba(255, 255, 255, 0.4)',
          }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
              {previewLetters.flatMap((row, r) => row.map((L, c) => (
                <Tile key={`${r}-${c}`} letter={L} size={48} state={isHL(r,c) ? 'pending' : 'normal'} />
              )))}
            </div>
          </div>
        </div>

        {/* Play button */}
        <div style={{ position: 'absolute', bottom: 196, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
          <button className="puffy" onClick={() => go('game')} style={{ width: 240, padding: '16px 22px', fontSize: 26 }}>
            <Icon.Play s={18} c="#7a4500" />
            <span style={{ color: '#7a4500' }}>PLAY</span>
            <span style={{
              position: 'absolute', top: 4, left: '20%', right: '20%', height: 12,
              background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.65), transparent)',
              borderRadius: 999, overflow: 'hidden',
            }}>
              <span style={{ position: 'absolute', inset: 0, background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.9), transparent)', animation: 'shimmer-strip 2.4s ease-in-out infinite' }} />
            </span>
          </button>
        </div>

        {/* Mode chip under play */}
        <div style={{ position: 'absolute', bottom: 158, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
          <button onClick={() => go('modes')} style={{
            border: 'none', cursor: 'pointer',
            display: 'inline-flex', alignItems: 'center', gap: 8,
            padding: '6px 14px',
            background: 'rgba(255,255,255,0.55)',
            backdropFilter: 'blur(8px)',
            borderRadius: 999,
            fontFamily: 'Fredoka', fontWeight: 500, fontSize: 13,
            color: '#3a2a78',
            boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.85)',
          }}>
            <span style={{ opacity: 0.7 }}>Mode</span>
            <span style={{ fontWeight: 600 }}>🇬🇧 Classic 4×4</span>
            <span style={{ opacity: 0.6 }}>›</span>
          </button>
        </div>

        {/* Bottom nav */}
        <div className="q-nav">
          <NavBtn label="Modes" tint="linear-gradient(180deg,#cdb6ff,#9c7af0)" onClick={() => go('modes')}>
            <Icon.Grid s={20} c="#fff" />
          </NavBtn>
          <NavBtn label="Shop" tint="linear-gradient(180deg,#ffb3d9,#ff6fae)" onClick={() => go('shop')}>
            <Icon.Cart s={20} c="#fff" />
          </NavBtn>
          <NavBtn label="Quests" tint="linear-gradient(180deg,#8ee8ad,#36c071)" onClick={() => openModal('quests')}>
            <Icon.Check s={20} c="#fff" />
          </NavBtn>
          <NavBtn label="Friends" tint="linear-gradient(180deg,#ffd97a,#ffa940)" onClick={() => openModal('locked')}>
            <Icon.Heart s={20} c="#fff" />
          </NavBtn>
        </div>
      </DreamBackground>
    </div>
  );
}

function StatChip({ icon, label, value, bg }) {
  return (
    <div style={{
      background: bg,
      borderRadius: 16, padding: '6px 10px',
      boxShadow: 'inset 0 -3px 0 rgba(180, 110, 0, 0.18), inset 0 1px 0 rgba(255,255,255,0.85), 0 3px 0 rgba(80, 50, 160, 0.18)',
      display: 'flex', alignItems: 'center', gap: 8,
    }}>
      <div style={{ display: 'grid', placeItems: 'center', flex: '0 0 auto' }}>{icon}</div>
      <div style={{ lineHeight: 1.1 }}>
        <div style={{ fontSize: 9, fontFamily: 'Nunito', fontWeight: 800, color: 'rgba(58, 42, 120, 0.65)', textTransform: 'uppercase', letterSpacing: 0.6 }}>{label}</div>
        <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 16, color: '#3a2a78' }}>{value}</div>
      </div>
    </div>
  );
}

function NavBtn({ children, label, tint, onClick }) {
  return (
    <button onClick={onClick} style={{
      flex: 1, border: 'none', cursor: 'pointer',
      background: tint,
      borderRadius: 18, padding: '10px 6px',
      boxShadow: 'inset 0 -4px 0 rgba(60, 30, 120, 0.35), inset 0 1px 0 rgba(255,255,255,0.55), 0 4px 0 rgba(60, 30, 120, 0.25)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
      color: 'white',
    }}>
      {children}
      <span style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 12, textShadow: '0 1px 0 rgba(60, 30, 120, 0.4)' }}>{label}</span>
    </button>
  );
}

window.MenuScreen = MenuScreen;

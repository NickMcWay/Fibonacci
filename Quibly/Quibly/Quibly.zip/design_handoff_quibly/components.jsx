// Quibly — shared building blocks
const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ---------- Sparkles & Confetti ----------
function Sparkles({ count = 14, area = 'absolute' }) {
  const dots = useMemo(() => Array.from({ length: count }).map((_, i) => ({
    left: Math.random() * 100,
    top: Math.random() * 100,
    delay: Math.random() * 2.4,
    size: 6 + Math.random() * 8,
  })), [count]);
  return (
    <div style={{ position: area, inset: 0, pointerEvents: 'none' }}>
      {dots.map((d, i) => (
        <div key={i} className="sparkle" style={{
          left: `${d.left}%`, top: `${d.top}%`,
          width: d.size, height: d.size,
          animationDelay: `${d.delay}s`
        }} />
      ))}
    </div>
  );
}

function Confetti({ burst = false, n = 30 }) {
  const pieces = useMemo(() => Array.from({ length: n }).map((_, i) => ({
    angle: (i / n) * Math.PI * 2 + Math.random() * 0.5,
    dist: 80 + Math.random() * 140,
    color: ['#ffc23d', '#ff7cb6', '#7c5ce5', '#4dd388', '#ffb678'][i % 5],
    rot: Math.random() * 360,
    delay: Math.random() * 0.1,
  })), [n]);
  if (!burst) return null;
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', display: 'grid', placeItems: 'center' }}>
      {pieces.map((p, i) => (
        <div key={i} className="confetto" style={{
          background: p.color,
          transform: `translate(${Math.cos(p.angle) * p.dist}px, ${Math.sin(p.angle) * p.dist}px) rotate(${p.rot}deg)`,
          opacity: 0,
          animation: `confetti-fly 900ms ${p.delay}s ease-out forwards`,
        }} />
      ))}
      <style>{`@keyframes confetti-fly{0%{transform:translate(0,0) rotate(0);opacity:0}15%{opacity:1}100%{opacity:0}}`}</style>
    </div>
  );
}

// ---------- Coin pill ----------
function CoinChip({ amount, big }) {
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: big ? '8px 14px' : '4px 10px 4px 6px',
      background: 'linear-gradient(180deg, #fff8da, #ffe39a)',
      borderRadius: 999,
      boxShadow: 'inset 0 -3px 0 rgba(180, 110, 0, 0.25), inset 0 1px 0 rgba(255,255,255,0.8), 0 2px 0 rgba(180, 110, 0, 0.25)',
      fontFamily: 'Fredoka', fontWeight: 600,
      color: '#7a4500',
      fontSize: big ? 18 : 14,
    }}>
      <span style={{
        width: big ? 22 : 18, height: big ? 22 : 18, borderRadius: '50%',
        background: 'radial-gradient(circle at 30% 25%, #fff5b3, #f0a420 70%)',
        boxShadow: 'inset -2px -3px 0 rgba(140, 80, 0, 0.4)',
        display: 'inline-block',
      }} />
      {amount.toLocaleString()}
    </div>
  );
}

// ---------- Letter Tile ----------
const SCRABBLE = {a:1,b:3,c:3,d:2,e:1,f:4,g:2,h:4,i:1,j:8,k:5,l:1,m:3,n:1,o:1,p:3,q:10,r:1,s:1,t:1,u:1,v:4,w:4,x:8,y:4,z:10};
function scrabbleVal(L) { return SCRABBLE[L.toLowerCase()] ?? 1; }

function Tile({ letter, size = 56, state = 'normal', coin = false, joker = false, style = {} }) {
  // state: normal | pending | selected | empty
  const cls = `q-tile ${state === 'pending' ? 'is-pending' : ''} ${state === 'selected' ? 'is-selected' : ''}`;
  const fontSize = size * 0.5;
  return (
    <div className={cls} style={{ width: size, height: size, fontSize, ...style }}>
      {!joker && <span className="q-tile__value">{scrabbleVal(letter)}</span>}
      {joker ? <span style={{ filter: 'drop-shadow(0 0 4px gold)' }}>★</span> : letter.toUpperCase()}
      {coin && <div className="q-tile__coin" />}
    </div>
  );
}

// ---------- Background ----------
function DreamBackground({ children }) {
  return (
    <div className="q-bg-dream">
      {/* clouds */}
      <div style={{
        position: 'absolute', bottom: -10, left: -20, right: -20, height: '40%',
        background: 'radial-gradient(ellipse 60% 80% at 20% 100%, rgba(255,255,255,0.4), transparent 60%), radial-gradient(ellipse 60% 70% at 80% 100%, rgba(255,200,210,0.5), transparent 60%)',
      }} />
      {/* horizon glow */}
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0, height: 80,
        background: 'radial-gradient(ellipse 70% 100% at 50% 100%, rgba(255, 220, 130, 0.85), transparent 70%)',
      }} />
      {/* cute side leaves */}
      <svg viewBox="0 0 60 200" style={{ position: 'absolute', bottom: 0, left: 0, width: 70, opacity: 0.95 }}>
        <ellipse cx="20" cy="180" rx="30" ry="22" fill="#9a7be8" />
        <ellipse cx="40" cy="170" rx="22" ry="14" fill="#8a6cd6" />
        <path d="M5 170 Q 0 130 8 100 Q 14 130 12 165 Z" fill="#3fb480" opacity="0.9" />
      </svg>
      <svg viewBox="0 0 60 200" style={{ position: 'absolute', bottom: 0, right: 0, width: 70, opacity: 0.95, transform: 'scaleX(-1)' }}>
        <ellipse cx="20" cy="180" rx="30" ry="22" fill="#c89cf2" />
        <ellipse cx="40" cy="170" rx="22" ry="14" fill="#a06fdf" />
        <path d="M5 170 Q 0 130 8 100 Q 14 130 12 165 Z" fill="#3fb480" opacity="0.85" />
      </svg>
      <Sparkles count={18} />
      {children}
    </div>
  );
}

// ---------- Logo ----------
function QuiblyLogo({ size = 56, dotColor = '#ffc23d' }) {
  return (
    <div style={{
      fontFamily: 'Fredoka', fontWeight: 600, fontSize: size,
      color: 'white',
      textShadow: '0 4px 0 rgba(80, 50, 160, 0.45), 0 8px 12px rgba(80, 50, 160, 0.3)',
      letterSpacing: '-0.02em', lineHeight: 1,
      position: 'relative', display: 'inline-block',
    }}>
      Qu<span style={{ position: 'relative' }}>i
        <span style={{
          position: 'absolute', top: -size * 0.18, left: '50%', transform: 'translateX(-50%)',
          width: size * 0.28, height: size * 0.28, borderRadius: '50%',
          background: `radial-gradient(circle at 35% 30%, #fff8b8, ${dotColor})`,
          boxShadow: 'inset -2px -3px 0 rgba(180, 110, 0, 0.45), 0 3px 0 rgba(180, 110, 0, 0.35)',
          animation: 'coin-bob 2s ease-in-out infinite'
        }} />
      </span>bly
    </div>
  );
}

// ---------- Modal frame ----------
function Modal({ open, onClose, children, dim = 0.55, anchor = 'center' }) {
  if (!open) return null;
  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 50,
      background: `rgba(40, 20, 80, ${dim})`,
      display: 'flex', alignItems: anchor === 'bottom' ? 'flex-end' : 'center', justifyContent: 'center',
      animation: 'fade-in 200ms ease',
    }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{
        animation: 'pop-in 320ms cubic-bezier(.34,1.56,.64,1)',
        width: '100%',
      }}>
        {children}
      </div>
      <style>{`@keyframes fade-in{from{opacity:0}to{opacity:1}}`}</style>
    </div>
  );
}

// ---------- Mini icons (no slop, geometric) ----------
const Icon = {
  Bomb: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
      <circle cx="11" cy="14" r="7" fill={c} />
      <path d="M16 8 L19 5" stroke={c} strokeWidth="2.4" strokeLinecap="round" />
      <circle cx="20" cy="4" r="1.6" fill="#ffc23d" />
    </svg>
  ),
  Hint: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
      <path d="M12 3 a6 6 0 0 1 4 10.5 V16 a1 1 0 0 1-1 1h-6 a1 1 0 0 1-1-1 v-2.5 A6 6 0 0 1 12 3 Z" fill={c}/>
      <rect x="9" y="18" width="6" height="2" rx="1" fill={c} />
      <rect x="10" y="21" width="4" height="1.5" rx="0.7" fill={c} />
    </svg>
  ),
  Wild: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
      <path d="M12 2 L14 9 L21 11 L14 13 L12 20 L10 13 L3 11 L10 9 Z" fill={c}/>
    </svg>
  ),
  Shuffle: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 7 L8 7 L16 17 L21 17"/>
      <path d="M3 17 L8 17 L11 13"/>
      <path d="M14 11 L16 7 L21 7"/>
      <path d="M18 4 L21 7 L18 10"/>
      <path d="M18 14 L21 17 L18 20"/>
    </svg>
  ),
  Trophy: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
      <path d="M7 4h10v5a5 5 0 0 1-10 0V4Z" fill={c}/>
      <path d="M5 5h2v3a2 2 0 1 1-2-2V5Zm14 0h-2v3a2 2 0 1 0 2-2V5Z" fill={c}/>
      <rect x="9" y="14" width="6" height="3" fill={c}/>
      <rect x="7" y="17" width="10" height="3" rx="1" fill={c}/>
    </svg>
  ),
  Cart: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
      <path d="M3 4h3l2 11h11l2-8H7" stroke={c} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/>
      <circle cx="9" cy="20" r="1.6" fill={c}/>
      <circle cx="18" cy="20" r="1.6" fill={c}/>
    </svg>
  ),
  Grid: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill={c}>
      <rect x="3" y="3" width="8" height="8" rx="2"/>
      <rect x="13" y="3" width="8" height="8" rx="2"/>
      <rect x="3" y="13" width="8" height="8" rx="2"/>
      <rect x="13" y="13" width="8" height="8" rx="2"/>
    </svg>
  ),
  Cog: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill={c}>
      <path d="M12 2l2 2 3-1 1 3 3 1-1 3 1 3-3 1-1 3-3-1-2 2-2-2-3 1-1-3-3-1 1-3-1-3 3-1 1-3 3 1Z"/>
      <circle cx="12" cy="12" r="3" fill="#fff"/>
    </svg>
  ),
  Play: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill={c}>
      <path d="M7 4 L20 12 L7 20 Z"/>
    </svg>
  ),
  Back: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M15 5l-7 7 7 7"/>
    </svg>
  ),
  Close: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2.6" strokeLinecap="round">
      <path d="M6 6 L18 18 M18 6 L6 18"/>
    </svg>
  ),
  Heart: ({ s = 22, c = '#ff7cb6' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill={c}>
      <path d="M12 21s-7-4.5-9.5-9.5C1 7 4.5 3 8 4.5c2 .8 3 2 4 3.5 1-1.5 2-2.7 4-3.5 3.5-1.5 7 2.5 5.5 7C19 16.5 12 21 12 21Z"/>
    </svg>
  ),
  Flame: ({ s = 22, c = '#ff8a3d' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill={c}>
      <path d="M12 2c1 4 4 5 4 9a4 4 0 0 1-8 0c0-2 1-3 2-4-1 0-2-1-2-3 1 0 3-1 4-2Z"/>
      <path d="M12 22a6 6 0 0 0 6-6c0-2-1-3-2-4 0 3-2 4-4 4s-4-1-4-4c-1 1-2 2-2 4a6 6 0 0 0 6 6Z" fill="#ffc23d"/>
    </svg>
  ),
  Crown: ({ s = 22, c = '#ffc23d' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill={c}>
      <path d="M3 8l4 4 5-7 5 7 4-4v10H3V8Z"/>
    </svg>
  ),
  Clock: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2.4" strokeLinecap="round">
      <circle cx="12" cy="12" r="9"/>
      <path d="M12 7v5l3 2"/>
    </svg>
  ),
  Speaker: ({ s = 22, c = '#fff', muted }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill={c}>
      <path d="M4 9h4l5-4v14l-5-4H4V9Z"/>
      {!muted && <path d="M16 8c2 1 2 7 0 8M19 5c4 2 4 12 0 14" stroke={c} strokeWidth="2.2" fill="none" strokeLinecap="round"/>}
      {muted && <path d="M16 9l5 6M21 9l-5 6" stroke={c} strokeWidth="2.2" fill="none" strokeLinecap="round"/>}
    </svg>
  ),
  Vibrate: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill={c}>
      <rect x="8" y="5" width="8" height="14" rx="2"/>
      <rect x="3" y="9" width="2" height="6" rx="1"/>
      <rect x="19" y="9" width="2" height="6" rx="1"/>
    </svg>
  ),
  Globe: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round">
      <circle cx="12" cy="12" r="9"/>
      <path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>
    </svg>
  ),
  Gift: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill={c}>
      <rect x="3" y="9" width="18" height="4" rx="1"/>
      <rect x="5" y="13" width="14" height="9" rx="1"/>
      <path d="M12 9v13M8 9c-2-3 1-6 4-3 3-3 6 0 4 3" stroke={c} strokeWidth="1.8" fill="none"/>
    </svg>
  ),
  Lock: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill={c}>
      <rect x="5" y="11" width="14" height="10" rx="2"/>
      <path d="M8 11V8a4 4 0 0 1 8 0v3" stroke={c} strokeWidth="2.4" fill="none" strokeLinecap="round"/>
    </svg>
  ),
  Check: ({ s = 22, c = '#fff' }) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 12l5 5L20 7"/>
    </svg>
  ),
};

// ---------- Pill button (compact) ----------
function CircleBtn({ children, onClick, size = 44, tint = 'rgba(255,255,255,0.55)' }) {
  return (
    <button onClick={onClick} style={{
      width: size, height: size, borderRadius: '50%',
      border: 'none',
      background: tint,
      backdropFilter: 'blur(8px)',
      boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.85), 0 4px 0 rgba(80,50,160,0.18), 0 8px 14px -4px rgba(80,50,160,0.3)',
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer',
      color: '#3a2a78',
    }}>{children}</button>
  );
}

Object.assign(window, { Sparkles, Confetti, CoinChip, Tile, scrabbleVal, DreamBackground, QuiblyLogo, Modal, Icon, CircleBtn });

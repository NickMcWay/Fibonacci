// Quibly Game Screen
function GameScreen({ go, state, setState, openModal }) {
  const [score, setScore] = React.useState(842);
  const [combo, setCombo] = React.useState(2);
  const [drawing, setDrawing] = React.useState(true);
  const board = [
    ['W','I','S','H'],
    ['O','★','R','A'],
    ['R','D','E','P'],
    ['B','Z','S','T'],
  ];
  // mark a draw path: W-I-S-H across row 0, with selected look
  const isSelected = (r,c) => r === 0 && c <= 3;
  const drawPath = [[0,0],[0,1],[0,2],[0,3]];

  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <DreamBackground>
        {/* Top bar */}
        <div style={{ position: 'absolute', top: 56, left: 16, right: 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <CircleBtn size={40} onClick={() => openModal('pause')}>
            <Icon.Back s={18} c="#3a2a78" />
          </CircleBtn>
          <div style={{
            background: 'rgba(255,255,255,0.55)', backdropFilter: 'blur(8px)',
            borderRadius: 999, padding: '4px 12px',
            boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.85)',
            display: 'inline-flex', alignItems: 'center', gap: 6,
            fontFamily: 'Fredoka', fontWeight: 600, fontSize: 13, color: '#3a2a78',
          }}>
            <Icon.Clock s={14} c="#3a2a78" />
            <span>2:14</span>
          </div>
          <div style={{ display: 'flex', gap: 6 }}>
            <CircleBtn size={36} onClick={() => go('shop')}><Icon.Cart s={16} c="#3a2a78" /></CircleBtn>
            <CircleBtn size={36}><Icon.Speaker s={16} c="#3a2a78" /></CircleBtn>
          </div>
        </div>

        {/* Score header */}
        <div style={{ position: 'absolute', top: 108, left: 18, right: 18 }}>
          <div className="q-card" style={{ padding: '10px 14px', borderRadius: 22 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr', gap: 8, alignItems: 'center' }}>
              <div>
                <div style={{ fontSize: 9, fontFamily: 'Nunito', fontWeight: 800, letterSpacing: 0.6, textTransform: 'uppercase', color: 'rgba(58,42,120,0.65)' }}>Score</div>
                <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 28, color: '#3a2a78', lineHeight: 1 }}>{score.toLocaleString()}</div>
              </div>
              <div style={{ borderLeft: '1px solid rgba(80,50,160,0.18)', paddingLeft: 10 }}>
                <div style={{ fontSize: 9, fontFamily: 'Nunito', fontWeight: 800, letterSpacing: 0.6, textTransform: 'uppercase', color: 'rgba(58,42,120,0.65)' }}>Best</div>
                <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 18, color: '#3a2a78', lineHeight: 1.1 }}>1,204</div>
              </div>
              <div style={{ borderLeft: '1px solid rgba(80,50,160,0.18)', paddingLeft: 10 }}>
                <div style={{ fontSize: 9, fontFamily: 'Nunito', fontWeight: 800, letterSpacing: 0.6, textTransform: 'uppercase', color: 'rgba(58,42,120,0.65)' }}>Coins</div>
                <CoinChip amount={state.coins} />
              </div>
            </div>
            {/* progress bar to next level */}
            <div style={{ marginTop: 8, height: 8, borderRadius: 999, background: 'rgba(80,50,160,0.12)', overflow: 'hidden', position: 'relative' }}>
              <div style={{
                width: '62%', height: '100%',
                background: 'linear-gradient(90deg, #ffd97a, #ff7cb6, #b39bff)',
                borderRadius: 999,
                boxShadow: 'inset 0 -2px 0 rgba(80,50,160,0.25)',
              }} />
              <div style={{ position: 'absolute', top: -3, left: '62%', transform: 'translateX(-50%)', fontSize: 14 }}>⭐</div>
            </div>
            <div style={{ marginTop: 4, display: 'flex', justifyContent: 'space-between', fontSize: 10, fontFamily: 'Nunito', fontWeight: 700, color: 'rgba(58,42,120,0.7)' }}>
              <span>Lvl 12</span>
              <span>520 / 840 xp</span>
            </div>
          </div>
        </div>

        {/* Combo ribbon */}
        {combo > 0 && (
          <div style={{ position: 'absolute', top: 206, left: 0, right: 0, display: 'flex', justifyContent: 'center' }}>
            <div style={{
              padding: '4px 14px',
              background: 'linear-gradient(180deg, #ffd97a, #ff8a3d)',
              borderRadius: 999,
              fontFamily: 'Fredoka', fontWeight: 600, fontSize: 13, color: 'white',
              boxShadow: 'inset 0 -3px 0 rgba(180, 70, 0, 0.4), 0 3px 0 rgba(180, 70, 0, 0.3)',
              textShadow: '0 1px 0 rgba(180, 70, 0, 0.5)',
              display: 'inline-flex', alignItems: 'center', gap: 6,
              animation: 'wiggle 1.6s ease-in-out infinite',
            }}>
              <Icon.Flame s={14} c="#fff" />
              COMBO ×{combo + 1}
            </div>
          </div>
        )}

        {/* Board */}
        <div style={{ position: 'absolute', top: 238, left: 16, right: 16, display: 'flex', justifyContent: 'center' }}>
          <div className="q-card" style={{
            padding: 12, borderRadius: 28,
            background: 'rgba(255,255,255,0.32)',
            position: 'relative',
          }}>
            <div style={{ position: 'relative' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
                {board.flatMap((row, r) => row.map((L, c) => {
                  const sel = isSelected(r,c);
                  return (
                    <div key={`${r}-${c}`} style={{ position: 'relative' }}>
                      <Tile letter={L} size={64} state={sel ? 'selected' : 'normal'} joker={L==='★'} coin={r===2 && c===3} />
                    </div>
                  );
                }))}
              </div>
              {/* Draw path connector */}
              {drawing && (
                <svg style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }} viewBox="0 0 100 100" preserveAspectRatio="none">
                  <line x1="11" y1="11" x2="89" y2="11" stroke="rgba(124, 92, 229, 0.85)" strokeWidth="2.6" strokeLinecap="round" strokeDasharray="0,0" />
                </svg>
              )}
            </div>
            {/* Word preview */}
            <div style={{
              position: 'absolute', bottom: 8, left: '50%', transform: 'translateX(-50%)',
              padding: '6px 16px',
              background: 'white',
              borderRadius: 999,
              boxShadow: '0 4px 0 rgba(80, 50, 160, 0.18), 0 8px 14px -4px rgba(80, 50, 160, 0.3)',
              fontFamily: 'Fredoka', fontWeight: 600, fontSize: 18,
              color: '#1f9d5b',
              display: 'inline-flex', alignItems: 'center', gap: 6,
              animation: 'pop-in 280ms cubic-bezier(.34,1.56,.64,1)',
            }}>
              WISH
              <span style={{ color: '#ff7cb6' }}>+24</span>
            </div>
          </div>
        </div>

        {/* Power-up bar */}
        <div style={{ position: 'absolute', bottom: 28, left: 16, right: 16 }}>
          <div className="q-card" style={{ padding: 8, borderRadius: 22, background: 'rgba(255,255,255,0.55)' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
              <PUBtn icon={<Icon.Hint s={20} c="#fff" />} label="Hint" tint="linear-gradient(180deg,#ffe27a,#ffb83a)" charges={2} pulsing />
              <PUBtn icon={<Icon.Shuffle s={20} c="#fff" />} label="Shuffle" tint="linear-gradient(180deg,#9ad4ff,#3398ff)" charges={1} />
              <PUBtn icon={<Icon.Wild s={20} c="#fff" />} label="Wild" tint="linear-gradient(180deg,#d6b6ff,#8c5ce5)" charges={0} cost={60} />
              <PUBtn icon={<Icon.Bomb s={20} c="#fff" />} label="Bomb" tint="linear-gradient(180deg,#ff9d8a,#ff5a44)" armed charges={1} />
            </div>
          </div>
        </div>

        {/* Recent words ticker */}
        <div style={{ position: 'absolute', top: 164, right: 16, display: combo > 0 ? 'none' : 'flex' }} />
      </DreamBackground>
    </div>
  );
}

function PUBtn({ icon, label, tint, charges, cost, armed, pulsing }) {
  return (
    <button style={{
      border: 'none', cursor: 'pointer',
      borderRadius: 16, padding: '8px 6px',
      background: charges > 0 ? tint : 'rgba(220, 210, 240, 0.7)',
      color: 'white',
      boxShadow: charges > 0
        ? 'inset 0 -3px 0 rgba(60, 30, 120, 0.35), inset 0 1px 0 rgba(255,255,255,0.55), 0 3px 0 rgba(60, 30, 120, 0.25)'
        : 'inset 0 0 0 1px rgba(80, 50, 160, 0.18)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
      position: 'relative',
      animation: armed ? 'wiggle 0.8s ease-in-out infinite' : 'none',
    }}>
      <div style={{
        width: 38, height: 38, borderRadius: '50%',
        background: charges > 0 ? 'rgba(255,255,255,0.18)' : 'rgba(255,255,255,0.5)',
        display: 'grid', placeItems: 'center',
        animation: pulsing ? 'pulse-ring 1.6s ease-out infinite' : 'none',
      }}>
        {React.cloneElement(icon, { c: charges > 0 ? '#fff' : '#9989c2' })}
      </div>
      <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 11, color: charges > 0 ? '#fff' : '#5a4a8a', textShadow: charges > 0 ? '0 1px 0 rgba(60,30,120,0.4)' : 'none' }}>{label}</div>
      {charges > 0 ? (
        <div style={{
          position: 'absolute', top: 4, right: 6,
          minWidth: 18, height: 18, padding: '0 4px',
          background: '#fff', color: '#3a2a78',
          borderRadius: 999, fontFamily: 'Fredoka', fontWeight: 600, fontSize: 11,
          display: 'grid', placeItems: 'center',
          boxShadow: '0 2px 0 rgba(60,30,120,0.25)',
        }}>×{charges}</div>
      ) : (
        <div style={{
          position: 'absolute', top: 4, right: 6,
          padding: '0 6px', height: 18,
          background: 'linear-gradient(180deg,#fff8da,#ffe39a)', color: '#7a4500',
          borderRadius: 999, fontFamily: 'Fredoka', fontWeight: 600, fontSize: 10,
          display: 'inline-flex', alignItems: 'center', gap: 3,
          boxShadow: '0 2px 0 rgba(180,110,0,0.25)',
        }}>
          <span style={{ width: 10, height: 10, borderRadius: '50%', background: 'radial-gradient(circle at 30% 25%, #fff5b3, #f0a420 70%)' }} />
          {cost}
        </div>
      )}
      {armed && (
        <div style={{
          position: 'absolute', bottom: -6, left: '50%', transform: 'translateX(-50%)',
          fontSize: 9, fontFamily: 'Fredoka', fontWeight: 600,
          color: 'white',
          background: '#ff5a44',
          padding: '2px 6px', borderRadius: 999,
          boxShadow: '0 2px 0 rgba(160, 30, 0, 0.4)',
        }}>ARMED</div>
      )}
    </button>
  );
}

window.GameScreen = GameScreen;

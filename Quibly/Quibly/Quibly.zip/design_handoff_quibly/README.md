# Handoff: Quibly — Playful Word-Tile Game UI

## Overview
Quibly is a casual mobile word-tile game (loosely Boggle-meets-2048: drag through adjacent letter tiles to spell words, score, chain combos). This bundle contains a hi-fi visual + interaction design for the iOS app spanning 5 screens and 8 pop-ups, with a deliberately playful, "puffy" aesthetic — chunky drop-shadows, bouncy animations, candy gradient skies, and Fredoka display type.

## About the Design Files
The files in this bundle are **design references created in HTML/JSX (rendered in-browser via Babel)** — prototypes showing intended look, layout, and behavior. They are **not production code to copy directly**.

The task is to **recreate these designs in the target codebase's environment** (likely React Native, SwiftUI, or Flutter for an iOS game) using its established patterns, animation primitives, and component libraries. If no codebase exists yet, React Native + Reanimated or SwiftUI are both natural fits for this aesthetic.

The HTML files use absolute positioning inside a fixed 390×844 iPhone frame; in production these layouts should be rebuilt with the framework's native layout system (Flexbox, Auto Layout, etc.) and made responsive across iPhone sizes.

## Fidelity
**High-fidelity (hifi)** — pixel-perfect mockups with final colors, typography, spacing, motion specs, and interaction details. Recreate the UI faithfully but use the codebase's established libraries for things like haptics, sound, in-app purchase, and persistence.

## Visual System

### Color tokens
| Token | Hex | Usage |
|---|---|---|
| `--ink` | `#3a2a78` | Primary text on light surfaces, deep grape |
| `--ink-soft` | `rgba(58,42,120,0.65)` | Secondary text |
| `--grape-1` | `#b39bff` | Primary gradient start |
| `--grape-2` | `#7c5ce5` | Primary gradient end |
| `--bubblegum-1` | `#ffd5ea` | Sky top |
| `--bubblegum-2` | `#ff7cb6` | Pink accent |
| `--peach-1` | `#ffc1a8` | Sky middle |
| `--sun-1` | `#ffe27a` | Sky bottom / coin |
| `--sun-2` | `#ffaf3a` | Coin shadow |
| `--mint-1` | `#8ee8ad` | Success / Zen mode |
| `--mint-2` | `#36c071` | Success ink |
| `--coral-1` | `#ff9d8a` | Bomb / danger soft |
| `--coral-2` | `#ff5a44` | Bomb ink |
| `--sky-1` | `#9ad4ff` | Blitz mode |
| `--sky-2` | `#3398ff` | Blitz ink |
| `--gold-deep` | `#7a4500` | Text-on-gold (CTA) |

**Sky background gradient (used on most screens):** `linear-gradient(180deg, #ffd5ea 0%, #ffc1a8 35%, #ffe27a 100%)`

### Typography
- **Display / UI:** Fredoka, weights 400/500/600/700 — used for all titles, button labels, scores, navigation. Set with text-shadows like `0 2px 0 rgba(80,50,160,0.4)` on color-on-color titles for a "puffy" effect.
- **Numerics / metadata:** Nunito, weights 600–900 — used for stat labels (uppercase), small captions, sub-labels.
- Both loaded from Google Fonts.

### Spacing & radius
- Screen padding: 16px horizontal
- Card radius: 18–28px (most cards 20–24px)
- Button radius: 999px (pills) or 18–22px (rectangular)
- Tile radius: 14px
- Modal radius: 24–28px

### Shadow system ("puffy")
The signature look. Every elevated element gets a layered shadow:
- **Inner bottom inset** (chunky lip): `inset 0 -4px 0 rgba(80,50,160,0.25)` (color matches the element's darker tone)
- **Inner top highlight** (sheen): `inset 0 1px 0 rgba(255,255,255,0.85)`
- **Solid drop** (cartoon offset, NOT a blur): `0 4px 0 rgba(80,50,160,0.22)`
- Optional ambient shadow underneath: `0 8px 18px -8px rgba(80,50,160,0.4)`

### Motion
- Bounce easing: `cubic-bezier(.34, 1.56, .64, 1)` — used on press, pop-in, tile-place
- Entry: `pop-in` 280–400ms (scale 0.8 → 1.0)
- Idle: `float-y` 3.4–4.1s ease-in-out infinite (translateY ±4px) on logo, tiles, trophy
- Press: `transform: translateY(2px)` + halve the bottom shadow
- Confetti burst: 30–40 particles with hue-rotated sparkles, 1200ms outward fan
- Sparkles: 10–12 randomly placed twinklers with 1.5–3s opacity loop

## Screens

### 1. Menu (`screen-menu.jsx`)
**Purpose:** Home / launch screen. Shows brand, key stats, board preview, and primary CTA.

**Layout (top → bottom):**
- **Top bar (top: 56)** — profile chip (left) + coins pill + heart pill (right). Profile chip = avatar circle + "Lvl 12 / Riley" stacked.
- **Floating tiles** — Q (top:118 left:12, rot −12°), B (top:184 right:18, rot +14°), Y (top:230 left:18, rot +8°). All gently floating.
- **Logo cluster (top: 130, centered)** — `QuiblyLogo` mark + "tap · spell · combo" tagline.
- **Stats row (top: 260)** — three pill stats: Best 1,204 / Streak 7🔥 / Words 142.
- **Mini board preview (top: 324, centered)** — 4×4 grid of small letter tiles inside a glass card with a "Today's Daily" badge.
- **Play button (bottom: 196, centered)** — large gold puffy pill, 240×~62, text "PLAY" + play icon, with shimmer sweep.
- **Mode chip (bottom: 158)** — "Classic 4×4 ›" small text button under PLAY.
- **Bottom tab bar (bottom: 0)** — 4 tabs: Home (active) / Modes / Shop / Settings, each 44×44 hit.

### 2. Game (`screen-game.jsx`)
**Purpose:** Active gameplay. The board is the focus.

- **Top bar (top: 56)** — pause button (left), timer pill 1:24 (center), shop+speaker icons (right).
- **Score header (top: 108)** — full-width glass card, 3 columns: Score 842 (28pt) / Goal 1000 + tiny progress bar / Best 1204.
- **Combo ribbon (top: 206, centered)** — only when combo > 0. Animated gradient pill: "🔥 ×2 COMBO".
- **Board card (top: 238, centered)** — 4×4 letter tiles, ~76px each, gap 6px, inside a translucent glass card. Active drag-trail rendered as colored connectors between tiles. Tiles can be styled "selected" (lift + glow), "bomb-armed" (coral tint), or "frozen" (blue overlay).
- **Word preview pill (bottom: 8 of board card)** — appears mid-drag: "WISH +24" (white pill, score in pink).
- **Power-up bar (bottom: 28)** — 4 chunky icon buttons: Shuffle / Bomb / Hint / Freeze. Each shows a charge badge top-right (number) or a coin-cost badge if zero. Tapping zero-charge → opens Buy Charge sheet.

### 3. Shop (`screen-shop.jsx`)
**Purpose:** Sell power-up bundles and coin packs.

- **Header (top: 0, padding: 48px 16px 16px)** — back button, "Shop" title, coins balance pill.
- **Hero pack (top: 110)** — gradient card "Starter Bundle" with $4.99 price, $9.99 strikethrough, "50% OFF" tag.
- **Section: Power-ups** — vertical list of 4 cards: Shuffle ×3 / Bomb ×3 / Hint ×5 / Freeze ×3. Each: tinted icon, name, qty, price button (gold pill).
- **Section: Coin packs** — 2×2 grid: 200 / 600 (popular) / 1500 / 4000 coins. Popular tile gets a pink "BEST VALUE" tag.
- **Section: Subscription** — "Quibly+" gradient card, $4.99/mo, perks list (no ads, daily coins, exclusive themes).

### 4. Modes (`screen-modes-settings.jsx`)
**Purpose:** Pick a game mode and language.

- **Top bar (top: 56)** — back, "Modes" title.
- **Language picker (top: 106)** — horizontal scroll pill row, 5 flag+name pills (English selected by default).
- **Mode tiles** — 2-col grid of 7 tiles: Classic, Extended, Challenge, Blitz (NEW), Zen, Daily Puzzle (TODAY), Duel (locked, "Lvl 15"). Each tile is a colored gradient with emoji icon, name, description, and stars (0–3) earned, or a lock chip.
- **Board size** — 3-col segmented selector: 4×4 / 5×5 / 6×6.
- **Start button** — gold puffy pill at bottom.

### 5. Settings (`screen-modes-settings.jsx`)
**Purpose:** Preferences.

Grouped list (iOS-style insets, but with Quibly chrome):
- **Audio & Haptics** — Sound (toggle), Music (toggle), Haptics (toggle)
- **Gameplay** — Auto-hints (toggle + sublabel "Glow tiles after 10s"), Language (picker), Default board (picker)
- **Look & Feel** — Dark mode (toggle), Tile theme (picker), Background (picker)
- **Account** — Restore purchases, Privacy, Terms (chevron rows)

Toggle switch: 48×28 pill, gradient mint when on, neutral when off, knob lifts with a small drop-shadow.

## Pop-ups (`screen-popups.jsx`)

Generic `Modal` wraps a dimmed backdrop + centered child. All popups use bouncy entry (`pop-in`).

1. **Game Over (`PopupGameOver`)** — Cream/peach card, floating gold trophy circle above, "New Best!" headline, 3 stats (Score / Words / Best Combo), "+85 earned" coin chip, Menu + Play Again buttons.
2. **Board Cleared (`PopupBoardCleared`)** — Full-screen confetti burst, no card, just big text "✨ Board Cleared! ✨" + "Amazing!" + "+50 bonus coins" pill.
3. **Buy Charge (`PopupBuyCharge`)** — Bottom sheet, drag-handle top, coral bomb icon, two buy cards (×1 for 75 coins / ×3 for 195 with "BEST VALUE" tag), coins balance row.
4. **Daily Reward (`PopupDailyReward`)** — Pink/peach/gold card, 7-day grid (days 1–6 small + day 7 big chest spanning row), today (day 3) is animated wiggle, claimed days greyed with check.
5. **Quests (`PopupQuests`)** — White card, 3 quest rows (each with icon, name, progress bar, claim/coin pill), weekly chest banner at bottom.
6. **Pause (`PopupPause`)** — Cream/pink card, "Paused" title, Resume / Restart / Quit buttons stacked.
7. **Profile (`PopupProfile`)** — White card, large gradient avatar, name + level + streak, XP bar, 3 stats, Close.
8. **Locked Feature (`PopupLocked`)** — Small white card, lock circle, "Coming soon" + "Friends & duels unlock at Level 15", Got it button.

## Interactions & Behavior
- **Tile drag (game):** finger down → tile selects → drag over adjacent (8-way) → trail line connects in real time → release: if valid word, score animates, tiles burst+respawn; if invalid, shake + fade.
- **Combo:** Successive valid words within ~2s extend a combo multiplier; ribbon pulses.
- **Power-up tap:** charges > 0 → arm mode; charges == 0 → open Buy Charge sheet.
- **Bottom-tab switch:** crossfade screens, 200ms.
- **Modal dismiss:** tap backdrop or close button → fade out 200ms + scale 0.95.
- **Status bar clearance:** all screens leave 50px clear at the top to avoid the iOS dynamic island; the Shop header reserves 48px top padding instead.

## State Management
Per-game state:
- `score`, `bestScore`, `combo`, `comboTimer`, `wordsCleared[]`
- `boardLetters[16]`, `selectedPath[]`, `currentWord`
- `powerUpCharges: { shuffle, bomb, hint, freeze }`
- `armedPowerUp` (null | id)

Persistent state:
- `coins`, `streak`, `level`, `xp`, `dailyClaimed[]`, `unlockedModes[]`, `settings: { sound, music, haptics, hints, dark, language, theme }`

Navigation: simple stack — menu ↔ game/shop/modes/settings, popups overlay current screen.

## Design Tokens (compact)
```
colors: see table above
spacing: 4 / 8 / 12 / 16 / 20 / 24
radius:  14 / 18 / 20 / 22 / 24 / 28 / 999
fonts:   Fredoka (display), Nunito (meta)
shadow:  layered inset-bottom + inset-top + solid drop, no blurs
motion:  300ms bounce, 4s float, 200ms fade
```

## Assets
No external assets — all artwork is rendered from CSS gradients, inline SVG (icons in `components.jsx`), and emoji. In production:
- Replace emoji mode icons with a custom illustration set
- Replace the SVG icon set with the codebase's existing icon library, matching the same stroke weight (~1.8)
- The `QuiblyLogo` is a stylized "Q" tile — keep as SVG or replace with a brand-team asset

## Files
- `Quibly Design.html` — entry point; loads all JSX modules
- `app.jsx` — root component, screen router, Tweaks panel wiring
- `components.jsx` — shared UI primitives (Tile, CircleBtn, Modal, Sparkles, Confetti, DreamBackground, Icon set, QuiblyLogo)
- `screen-menu.jsx` — Menu screen
- `screen-game.jsx` — Game screen + power-up button
- `screen-shop.jsx` — Shop screen
- `screen-modes-settings.jsx` — Modes + Settings (two screens, one file)
- `screen-popups.jsx` — All 8 pop-ups
- `ios-frame.jsx` — iPhone frame chrome (drop-in starter, replace with native shell)
- `tweaks-panel.jsx` — design-time control panel (NOT for production)
- `styles.css` — global keyframes, Fredoka/Nunito fallbacks, scrollable utility, puffy-button class

## Open the prototype
Open `Quibly Design.html` in a browser. Use the Tweaks panel (bottom-right) to switch between phone and pop-up gallery views, jump screens, and force any pop-up open.

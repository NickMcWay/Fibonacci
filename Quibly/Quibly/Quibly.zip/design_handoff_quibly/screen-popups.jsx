// Quibly Popups
function PopupGameOver({ onClose, onPlayAgain, score }) {
  return (
    <Modal open onClose={onClose}>
      <div style={{ position: 'relative', margin: '0 24px' }}>
        <Confetti burst n={30} />
        <div style={{
          background: 'linear-gradient(180deg, #fff8e8, #ffe5b8)',
          borderRadius: 28, padding: '28px 22px 20px', textAlign: 'center',
          boxShadow: 'inset 0 -6px 0 rgba(180,110,0,0.28), inset 0 2px 0 rgba(255,255,255,0.85), 0 12px 0 rgba(80,50,160,0.25), 0 22px 40px -10px rgba(80,50,160,0.5)',
          position: 'relative',
        }}>
          {/* Trophy */}
          <div style={{ position: 'absolute', top: -42, left: '50%', transform: 'translateX(-50%)', animation: 'float-y 2.4s ease-in-out infinite' }}>
            <div style={{
              width: 80, height: 80, borderRadius: '50%',
              background: 'radial-gradient(circle at 30% 30%, #fff8b3, #ffc23d 70%)',
              display: 'grid', placeItems: 'center',
              boxShadow: 'inset 0 -5px 0 rgba(180,110,0,0.4), 0 6px 0 rgba(180,110,0,0.4)',
            }}>
              <Icon.Trophy s={42} c="#7a4500" />
            </div>
          </div>
          <div style={{ height: 40 }} />
          <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 28, color: '#3a2a78' }}>New Best!</div>
          <div style={{ fontFamily: 'Nunito', fontWeight: 700, fontSize: 12, color: 'rgba(58,42,120,0.65)' }}>You beat your record by 142 points</div>

          <div style={{
            margin: '14px 6px', padding: '14px 16px', borderRadius: 18,
            background: 'rgba(255,255,255,0.65)',
            display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8,
          }}>
            <Stat label="Score" value={score} />
            <Stat label="Words" value="14" />
            <Stat label="Best Combo" value="×4" />
          </div>

          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            padding: '6px 14px', borderRadius: 999,
            background: 'linear-gradient(180deg,#fff8da,#ffe39a)',
            color: '#7a4500', fontFamily: 'Fredoka', fontWeight: 600, fontSize: 14,
            boxShadow: 'inset 0 -2px 0 rgba(180,110,0,0.3), 0 2px 0 rgba(180,110,0,0.3)',
          }}>
            <span style={{ width: 16, height: 16, borderRadius: '50%', background: 'radial-gradient(circle at 30% 25%, #fff5b3, #f0a420 70%)' }} />
            +85 earned
          </div>

          <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
            <button className="puffy ghost" style={{ flex: 1, fontSize: 16 }} onClick={onClose}>Menu</button>
            <button className="puffy" style={{ flex: 1.4, fontSize: 18 }} onClick={onPlayAgain}>
              <Icon.Play s={14} c="#7a4500" /><span style={{ color: '#7a4500' }}>Play Again</span>
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
}

function Stat({ label, value }) {
  return (
    <div>
      <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 9, color: 'rgba(58,42,120,0.6)', textTransform: 'uppercase', letterSpacing: 0.6 }}>{label}</div>
      <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 18, color: '#3a2a78' }}>{value}</div>
    </div>
  );
}

function PopupBoardCleared({ onClose }) {
  return (
    <Modal open onClose={onClose} dim={0.3}>
      <div style={{ textAlign: 'center', position: 'relative' }}>
        <Confetti burst n={40} />
        <div style={{
          fontFamily: 'Fredoka', fontWeight: 600, fontSize: 38,
          color: 'white', textShadow: '0 4px 0 rgba(80,50,160,0.45), 0 8px 16px rgba(80,50,160,0.4)',
          animation: 'pop-in 400ms cubic-bezier(.34,1.56,.64,1)',
        }}>✨ Board Cleared! ✨</div>
        <div style={{
          fontFamily: 'Fredoka', fontWeight: 600, fontSize: 22, color: '#ffe27a',
          textShadow: '0 2px 0 rgba(180,110,0,0.5)', marginTop: 6,
        }}>Amazing!</div>
        <div style={{
          marginTop: 14, display: 'inline-flex', alignItems: 'center', gap: 6,
          padding: '6px 16px', borderRadius: 999,
          background: 'rgba(255,255,255,0.95)',
          fontFamily: 'Fredoka', fontWeight: 600, fontSize: 16, color: '#3a2a78',
          boxShadow: '0 4px 0 rgba(80,50,160,0.25)',
        }}>
          <span style={{ width: 16, height: 16, borderRadius: '50%', background: 'radial-gradient(circle at 30% 25%, #fff5b3, #f0a420 70%)' }} />
          +50 bonus coins
        </div>
      </div>
    </Modal>
  );
}

function PopupBuyCharge({ onClose }) {
  return (
    <Modal open onClose={onClose} anchor="bottom">
      <div style={{
        background: 'white',
        borderRadius: '28px 28px 0 0', padding: '12px 22px 30px',
        boxShadow: '0 -8px 30px rgba(80,50,160,0.3)',
      }}>
        <div style={{ width: 36, height: 4, borderRadius: 999, background: 'rgba(80,50,160,0.25)', margin: '6px auto 14px' }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 60, height: 60, borderRadius: 18,
            background: 'linear-gradient(180deg,#ff9d8a,#ff5a44)',
            display: 'grid', placeItems: 'center',
            boxShadow: 'inset 0 -3px 0 rgba(160,30,0,0.4), 0 3px 0 rgba(160,30,0,0.3)',
          }}>
            <Icon.Bomb s={30} c="#fff" />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 22, color: '#3a2a78' }}>Out of Bombs!</div>
            <div style={{ fontFamily: 'Nunito', fontWeight: 700, fontSize: 12, color: 'rgba(58,42,120,0.7)' }}>Clear a full row + column with one tap.</div>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginTop: 16 }}>
          <BuyCard qty={1} cost={75} />
          <BuyCard qty={3} cost={195} discount="13% off" popular />
        </div>

        <div style={{ marginTop: 12, padding: '10px 14px', borderRadius: 14, background: 'rgba(80,50,160,0.06)', display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ width: 22, height: 22, borderRadius: '50%', background: 'radial-gradient(circle at 30% 25%, #fff5b3, #f0a420 70%)' }} />
          <div style={{ flex: 1, fontFamily: 'Fredoka', fontWeight: 600, fontSize: 14, color: '#3a2a78' }}>You have 125 coins</div>
          <button onClick={onClose} style={{
            border: 'none', background: 'none', cursor: 'pointer',
            fontFamily: 'Fredoka', fontWeight: 600, fontSize: 13, color: 'rgba(58,42,120,0.7)',
          }}>Get more →</button>
        </div>
      </div>
    </Modal>
  );
}

function BuyCard({ qty, cost, discount, popular }) {
  return (
    <div style={{
      borderRadius: 18, padding: 12, textAlign: 'center', position: 'relative',
      background: popular ? 'linear-gradient(180deg,#fff5d4,#ffd97a)' : 'rgba(80,50,160,0.06)',
      boxShadow: popular ? 'inset 0 -3px 0 rgba(180,110,0,0.3), 0 3px 0 rgba(180,110,0,0.3)' : 'inset 0 0 0 1px rgba(80,50,160,0.18)',
    }}>
      {popular && <div style={{ position: 'absolute', top: -8, left: '50%', transform: 'translateX(-50%)', background: '#ff7cb6', color: 'white', padding: '2px 8px', borderRadius: 999, fontFamily: 'Fredoka', fontWeight: 600, fontSize: 9, boxShadow: '0 2px 0 rgba(160,30,90,0.4)' }}>BEST VALUE</div>}
      <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 22, color: '#3a2a78' }}>×{qty}</div>
      {discount && <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 10, color: '#1f9d5b' }}>{discount}</div>}
      <div style={{
        marginTop: 8, padding: '6px 0', borderRadius: 999,
        background: 'linear-gradient(180deg,#fff8da,#ffe39a)', color: '#7a4500',
        fontFamily: 'Fredoka', fontWeight: 600, fontSize: 14,
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 4, width: '100%',
        boxShadow: 'inset 0 -2px 0 rgba(180,110,0,0.3)',
      }}>
        <span style={{ width: 14, height: 14, borderRadius: '50%', background: 'radial-gradient(circle at 30% 25%, #fff5b3, #f0a420 70%)' }} />
        {cost}
      </div>
    </div>
  );
}

function PopupDailyReward({ onClose }) {
  const days = [
    { d: 1, r: '+25', cl: true }, { d: 2, r: '+50', cl: true },
    { d: 3, r: '💡', cl: false, today: true }, { d: 4, r: '+100' },
    { d: 5, r: '🔀' }, { d: 6, r: '+200' }, { d: 7, r: '🎁', big: true },
  ];
  return (
    <Modal open onClose={onClose}>
      <div style={{ margin: '0 24px', position: 'relative' }}>
        <Sparkles count={12} />
        <div style={{
          background: 'linear-gradient(180deg, #ffd5ea 0%, #ffc1a8 60%, #ffe27a 100%)',
          borderRadius: 28, padding: '24px 18px 20px', textAlign: 'center',
          boxShadow: 'inset 0 -6px 0 rgba(180,30,90,0.3), inset 0 2px 0 rgba(255,255,255,0.7), 0 12px 0 rgba(80,50,160,0.25), 0 22px 40px -10px rgba(80,50,160,0.5)',
          position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 26, color: '#3a2a78', textShadow: '0 1px 0 rgba(255,255,255,0.4)' }}>Daily Reward 🎁</div>
          <div style={{ fontFamily: 'Nunito', fontWeight: 700, fontSize: 12, color: 'rgba(58,42,120,0.7)' }}>Day 3 · keep your streak alive!</div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6, marginTop: 14 }}>
            {days.slice(0,4).map(d => <DayBox key={d.d} {...d} />)}
            {days.slice(4).map(d => <DayBox key={d.d} {...d} />)}
          </div>

          <button className="puffy" style={{ marginTop: 16, width: '100%' }}>
            <span style={{ color: '#7a4500' }}>Claim Today</span>
            <Icon.Hint s={14} c="#7a4500" />
          </button>
        </div>
      </div>
    </Modal>
  );
}

function DayBox({ d, r, cl, today, big }) {
  return (
    <div style={{
      padding: 8, borderRadius: 14,
      gridColumn: big ? 'span 4' : 'auto',
      background: today ? 'linear-gradient(180deg,#ffe27a,#ffaf3a)' : cl ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.7)',
      boxShadow: today ? 'inset 0 -3px 0 rgba(180,90,0,0.4), 0 3px 0 rgba(180,90,0,0.3)' : 'inset 0 0 0 1px rgba(80,50,160,0.2)',
      opacity: cl ? 0.55 : 1,
      position: 'relative',
      animation: today ? 'wiggle 1.5s ease-in-out infinite' : 'none',
    }}>
      <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 9, color: today ? 'rgba(255,255,255,0.95)' : 'rgba(58,42,120,0.6)', textTransform: 'uppercase' }}>Day {d}</div>
      <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: big ? 22 : 16, color: today ? 'white' : '#3a2a78', textShadow: today ? '0 1px 0 rgba(180,90,0,0.4)' : 'none' }}>{r}</div>
      {cl && <div style={{ position: 'absolute', top: 4, right: 4 }}><Icon.Check s={12} c="#1f9d5b" /></div>}
    </div>
  );
}

function PopupQuests({ onClose }) {
  const quests = [
    { name: 'Score 500 in one game', p: 320, t: 500, r: 50, icon: <Icon.Trophy s={18} c="#fff" />, color: 'linear-gradient(180deg,#ffd97a,#ff8a3d)' },
    { name: 'Spell 5 words ≥ 5 letters', p: 3, t: 5, r: 30, icon: <span style={{ fontSize: 16 }}>🔤</span>, color: 'linear-gradient(180deg,#b39bff,#7c5ce5)' },
    { name: 'Trigger a ×3 combo', p: 0, t: 1, r: 75, icon: <Icon.Flame s={18} c="#fff" />, color: 'linear-gradient(180deg,#ff9d8a,#ff5a44)' },
  ];
  return (
    <Modal open onClose={onClose}>
      <div style={{ margin: '0 20px' }}>
        <div style={{
          background: 'white', borderRadius: 24, padding: 18,
          boxShadow: '0 12px 30px rgba(80,50,160,0.4)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
            <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 22, color: '#3a2a78' }}>Daily Quests</div>
            <button onClick={onClose} style={{ border: 'none', background: 'none', cursor: 'pointer', padding: 0 }}><Icon.Close s={20} c="#3a2a78" /></button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {quests.map((q, i) => {
              const pct = Math.min(100, (q.p / q.t) * 100);
              const done = q.p >= q.t;
              return (
                <div key={i} style={{ padding: 12, borderRadius: 18, background: 'rgba(80,50,160,0.05)' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 42, height: 42, borderRadius: 14, background: q.color, display: 'grid', placeItems: 'center', boxShadow: 'inset 0 -2px 0 rgba(60,30,120,0.3)' }}>{q.icon}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 14, color: '#3a2a78' }}>{q.name}</div>
                      <div style={{ marginTop: 6, height: 8, borderRadius: 999, background: 'rgba(80,50,160,0.12)', position: 'relative', overflow: 'hidden' }}>
                        <div style={{ width: `${pct}%`, height: '100%', background: 'linear-gradient(90deg,#8ee8ad,#36c071)', borderRadius: 999 }} />
                      </div>
                      <div style={{ fontFamily: 'Nunito', fontWeight: 700, fontSize: 10, color: 'rgba(58,42,120,0.65)', marginTop: 2 }}>{q.p}/{q.t}</div>
                    </div>
                    <div style={{
                      display: 'inline-flex', alignItems: 'center', gap: 4,
                      padding: '6px 10px', borderRadius: 999,
                      background: done ? 'linear-gradient(180deg,#8ee8ad,#36c071)' : 'linear-gradient(180deg,#fff8da,#ffe39a)',
                      color: done ? 'white' : '#7a4500',
                      fontFamily: 'Fredoka', fontWeight: 600, fontSize: 13,
                      boxShadow: 'inset 0 -2px 0 rgba(0,0,0,0.18), 0 2px 0 rgba(0,0,0,0.18)',
                    }}>
                      {done ? <Icon.Check s={12} c="#fff" /> : <span style={{ width: 12, height: 12, borderRadius: '50%', background: 'radial-gradient(circle at 30% 25%, #fff5b3, #f0a420 70%)' }} />}
                      {done ? 'Claim' : q.r}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div style={{ marginTop: 12, padding: 10, borderRadius: 14, background: 'linear-gradient(135deg,#b39bff,#ff7cb6)', color: 'white', display: 'flex', alignItems: 'center', gap: 10 }}>
            <Icon.Crown s={22} c="#ffe27a" />
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 14 }}>Weekly Chest</div>
              <div style={{ fontFamily: 'Nunito', fontWeight: 700, fontSize: 11, opacity: 0.9 }}>Complete 21/30 quests to unlock</div>
            </div>
            <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 18 }}>21/30</div>
          </div>
        </div>
      </div>
    </Modal>
  );
}

function PopupPause({ onClose, onMenu, onRestart }) {
  return (
    <Modal open onClose={onClose}>
      <div style={{ margin: '0 32px' }}>
        <div style={{
          background: 'linear-gradient(180deg,#fff8e8,#ffd5ea)',
          borderRadius: 26, padding: '20px 18px',
          boxShadow: 'inset 0 -5px 0 rgba(180,30,90,0.18), 0 10px 0 rgba(80,50,160,0.22), 0 22px 40px -10px rgba(80,50,160,0.45)',
        }}>
          <div style={{ textAlign: 'center', fontFamily: 'Fredoka', fontWeight: 600, fontSize: 26, color: '#3a2a78' }}>Paused</div>
          <div style={{ textAlign: 'center', fontFamily: 'Nunito', fontWeight: 700, fontSize: 12, color: 'rgba(58,42,120,0.65)', marginBottom: 14 }}>Take a breath. Take a sip. ☕</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <button className="puffy" onClick={onClose}><Icon.Play s={14} c="#7a4500" /><span style={{ color: '#7a4500' }}>Resume</span></button>
            <button className="puffy grape" onClick={onRestart}><Icon.Shuffle s={14} c="#fff" />Restart</button>
            <button className="puffy ghost" onClick={onMenu}>Quit to Menu</button>
          </div>
        </div>
      </div>
    </Modal>
  );
}

function PopupProfile({ onClose }) {
  return (
    <Modal open onClose={onClose}>
      <div style={{ margin: '0 24px' }}>
        <div style={{ background: 'white', borderRadius: 24, padding: 20, textAlign: 'center', boxShadow: '0 12px 30px rgba(80,50,160,0.4)' }}>
          <div style={{ width: 80, height: 80, borderRadius: '50%', background: 'linear-gradient(135deg,#ffd5ea,#b39bff)', margin: '0 auto', display: 'grid', placeItems: 'center', fontFamily: 'Fredoka', fontWeight: 600, fontSize: 36, color: 'white', textShadow: '0 2px 0 rgba(80,50,160,0.4)', boxShadow: 'inset 0 -4px 0 rgba(80,50,160,0.35), 0 4px 0 rgba(80,50,160,0.3)' }}>R</div>
          <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 22, color: '#3a2a78', marginTop: 8 }}>Riley</div>
          <div style={{ fontFamily: 'Nunito', fontWeight: 700, fontSize: 12, color: 'rgba(58,42,120,0.6)' }}>Level 12 · 7-day streak 🔥</div>
          <div style={{ marginTop: 10, height: 8, borderRadius: 999, background: 'rgba(80,50,160,0.12)', overflow: 'hidden' }}>
            <div style={{ width: '62%', height: '100%', background: 'linear-gradient(90deg,#ffd97a,#ff7cb6,#b39bff)', borderRadius: 999 }} />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8, marginTop: 14 }}>
            <Stat label="Best" value="1,204" />
            <Stat label="Games" value="48" />
            <Stat label="Longest" value="QUIBLY" />
          </div>
          <button className="puffy ghost" style={{ marginTop: 14, width: '100%' }} onClick={onClose}>Close</button>
        </div>
      </div>
    </Modal>
  );
}

function PopupLocked({ onClose }) {
  return (
    <Modal open onClose={onClose}>
      <div style={{ margin: '0 36px' }}>
        <div style={{ background: 'white', borderRadius: 22, padding: 18, textAlign: 'center', boxShadow: '0 12px 30px rgba(80,50,160,0.4)' }}>
          <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'linear-gradient(180deg,#cdb6ff,#9c7af0)', margin: '0 auto', display: 'grid', placeItems: 'center', boxShadow: 'inset 0 -3px 0 rgba(50,25,110,0.4)' }}>
            <Icon.Lock s={26} c="#fff" />
          </div>
          <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 20, color: '#3a2a78', marginTop: 10 }}>Coming soon</div>
          <div style={{ fontFamily: 'Nunito', fontWeight: 700, fontSize: 12, color: 'rgba(58,42,120,0.65)', marginTop: 4 }}>Friends & duels unlock at Level 15.</div>
          <button className="puffy" style={{ marginTop: 14, width: '100%' }} onClick={onClose}>
            <span style={{ color: '#7a4500' }}>Got it</span>
          </button>
        </div>
      </div>
    </Modal>
  );
}

window.PopupGameOver = PopupGameOver;
window.PopupBoardCleared = PopupBoardCleared;
window.PopupBuyCharge = PopupBuyCharge;
window.PopupDailyReward = PopupDailyReward;
window.PopupQuests = PopupQuests;
window.PopupPause = PopupPause;
window.PopupProfile = PopupProfile;
window.PopupLocked = PopupLocked;

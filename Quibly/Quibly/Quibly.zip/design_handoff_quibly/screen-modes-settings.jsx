// Quibly Modes + Settings + Popups
function ModesScreen({ go, state, setState, openModal }) {
  const modes = [
    { id: 'classic', icon: '🟪', label: 'Classic', desc: '4×4 board · the original', color: 'linear-gradient(135deg,#b39bff,#7c5ce5)', stars: 3, locked: false },
    { id: 'extended', icon: '🟫', label: 'Extended', desc: '5×5 · more room to combo', color: 'linear-gradient(135deg,#ffb3d9,#ff7cb6)', stars: 2, locked: false },
    { id: 'challenge', icon: '🟧', label: 'Challenge', desc: '6×6 · for word wizards', color: 'linear-gradient(135deg,#ffd97a,#ff8a3d)', stars: 1, locked: false },
    { id: 'blitz', icon: '⚡', label: 'Blitz', desc: '90 seconds · score sprint', color: 'linear-gradient(135deg,#9ad4ff,#3398ff)', stars: 0, locked: false, badge: 'NEW' },
    { id: 'zen', icon: '🍃', label: 'Zen', desc: 'No game-over · just vibes', color: 'linear-gradient(135deg,#8ee8ad,#36c071)', stars: 0, locked: false },
    { id: 'daily', icon: '📅', label: 'Daily Puzzle', desc: 'Same board worldwide', color: 'linear-gradient(135deg,#ffe27a,#ffaf3a)', stars: 0, locked: false, badge: 'TODAY' },
    { id: 'duel', icon: '⚔️', label: 'Duel', desc: 'Async vs. friends', color: 'linear-gradient(135deg,#ff9d8a,#ff5a44)', stars: 0, locked: true, unlock: 'Lvl 15' },
  ];

  const langs = [
    { flag: '🇬🇧', name: 'English', sel: true }, { flag: '🇳🇱', name: 'Dutch' }, { flag: '🇩🇪', name: 'German' }, { flag: '🇫🇷', name: 'French' }, { flag: '🇪🇸', name: 'Spanish' },
  ];

  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <DreamBackground>
        <div style={{ position: 'absolute', top: 56, left: 16, right: 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <CircleBtn size={40} onClick={() => go('menu')}><Icon.Back s={18} c="#3a2a78" /></CircleBtn>
          <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 22, color: 'white', textShadow: '0 2px 0 rgba(80,50,160,0.4)' }}>Modes</div>
          <div style={{ width: 40 }} />
        </div>

        <div className="scrollable" style={{ position: 'absolute', top: 106, bottom: 0, left: 0, right: 0, padding: '6px 16px 30px' }}>
          {/* Language picker */}
          <div className="q-card" style={{ padding: 12, borderRadius: 20, marginTop: 6 }}>
            <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 14, color: '#3a2a78', marginBottom: 8, display: 'inline-flex', alignItems: 'center', gap: 6 }}>
              <Icon.Globe s={16} c="#3a2a78" /> Language
            </div>
            <div style={{ display: 'flex', gap: 6, overflowX: 'auto' }}>
              {langs.map(l => (
                <div key={l.name} style={{
                  flex: '0 0 auto', padding: '6px 12px', borderRadius: 999,
                  background: l.sel ? 'linear-gradient(180deg,#b39bff,#7c5ce5)' : 'rgba(255,255,255,0.6)',
                  color: l.sel ? 'white' : '#3a2a78',
                  fontFamily: 'Fredoka', fontWeight: 600, fontSize: 13,
                  boxShadow: l.sel ? 'inset 0 -3px 0 rgba(50,25,110,0.4), 0 2px 0 rgba(50,25,110,0.3)' : 'inset 0 0 0 1px rgba(80,50,160,0.18)',
                  textShadow: l.sel ? '0 1px 0 rgba(50,25,110,0.45)' : 'none',
                  display: 'inline-flex', alignItems: 'center', gap: 6,
                }}>
                  <span style={{ fontSize: 16 }}>{l.flag}</span>{l.name}
                </div>
              ))}
            </div>
          </div>

          {/* Mode tiles */}
          <div style={{ marginTop: 14, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {modes.map(m => (
              <div key={m.id} style={{
                background: m.color,
                borderRadius: 22, padding: 12, color: 'white',
                position: 'relative', overflow: 'hidden',
                boxShadow: 'inset 0 -5px 0 rgba(60,30,120,0.3), 0 5px 0 rgba(60,30,120,0.22)',
                opacity: m.locked ? 0.85 : 1,
                minHeight: 130,
                cursor: m.locked ? 'default' : 'pointer',
              }}>
                {m.badge && (
                  <div style={{
                    position: 'absolute', top: 8, right: 8,
                    background: '#ffc23d', color: '#7a4500',
                    fontFamily: 'Fredoka', fontWeight: 600, fontSize: 9,
                    padding: '2px 7px', borderRadius: 999,
                    boxShadow: '0 2px 0 rgba(180,110,0,0.4)',
                  }}>{m.badge}</div>
                )}
                <div style={{ fontSize: 32, lineHeight: 1, marginBottom: 6 }}>{m.icon}</div>
                <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 18, textShadow: '0 2px 0 rgba(60,30,120,0.4)' }}>{m.label}</div>
                <div style={{ fontFamily: 'Nunito', fontWeight: 700, fontSize: 11, opacity: 0.95, marginTop: 2 }}>{m.desc}</div>
                {m.locked ? (
                  <div style={{ marginTop: 8, display: 'inline-flex', alignItems: 'center', gap: 4, padding: '3px 8px', background: 'rgba(0,0,0,0.25)', borderRadius: 999, fontFamily: 'Fredoka', fontWeight: 600, fontSize: 11 }}>
                    <Icon.Lock s={11} c="#fff" /> {m.unlock}
                  </div>
                ) : (
                  <div style={{ marginTop: 8, display: 'flex', gap: 2 }}>
                    {[0,1,2].map(i => (
                      <span key={i} style={{ fontSize: 14, color: i < m.stars ? '#ffe27a' : 'rgba(255,255,255,0.4)' }}>★</span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Board size */}
          <div className="q-card" style={{ padding: 12, borderRadius: 20, marginTop: 14 }}>
            <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 14, color: '#3a2a78', marginBottom: 8 }}>Board Size</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
              {[
                { n: 4, label: 'Classic' }, { n: 5, label: 'Extended' }, { n: 6, label: 'Challenge' },
              ].map((b, i) => (
                <div key={b.n} style={{
                  borderRadius: 16, padding: '10px 6px', textAlign: 'center',
                  background: i === 0 ? 'linear-gradient(180deg,#b39bff,#7c5ce5)' : 'rgba(255,255,255,0.55)',
                  color: i === 0 ? 'white' : '#3a2a78',
                  boxShadow: i === 0 ? 'inset 0 -3px 0 rgba(50,25,110,0.4), 0 3px 0 rgba(50,25,110,0.3)' : 'inset 0 0 0 1px rgba(80,50,160,0.18)',
                  textShadow: i === 0 ? '0 1px 0 rgba(50,25,110,0.45)' : 'none',
                }}>
                  <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 18 }}>{b.n}×{b.n}</div>
                  <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 10, opacity: 0.85 }}>{b.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{ marginTop: 18, display: 'flex', justifyContent: 'center' }}>
            <button className="puffy" onClick={() => go('game')} style={{ width: 220 }}>
              <Icon.Play s={16} c="#7a4500" /><span style={{ color: '#7a4500' }}>Start</span>
            </button>
          </div>
        </div>
      </DreamBackground>
    </div>
  );
}

function SettingsScreen({ go, state, setState }) {
  const [sound, setSound] = React.useState(true);
  const [music, setMusic] = React.useState(true);
  const [haptics, setHaptics] = React.useState(true);
  const [hints, setHints] = React.useState(true);
  const [dark, setDark] = React.useState(false);

  return (
    <div style={{ position: 'absolute', inset: 0 }}>
      <DreamBackground>
        <div style={{ position: 'absolute', top: 56, left: 16, right: 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <CircleBtn size={40} onClick={() => go('menu')}><Icon.Back s={18} c="#3a2a78" /></CircleBtn>
          <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 22, color: 'white', textShadow: '0 2px 0 rgba(80,50,160,0.4)' }}>Settings</div>
          <div style={{ width: 40 }} />
        </div>

        <div className="scrollable" style={{ position: 'absolute', top: 106, bottom: 0, left: 0, right: 0, padding: '6px 16px 30px' }}>
          <SettingsGroup title="Audio & Haptics">
            <SettingRow icon={<Icon.Speaker s={18} c="#3a2a78" />} label="Sound effects" value={sound} onChange={setSound} />
            <SettingRow icon={<span style={{ fontSize: 18 }}>🎵</span>} label="Music" value={music} onChange={setMusic} />
            <SettingRow icon={<Icon.Vibrate s={18} c="#3a2a78" />} label="Haptics" value={haptics} onChange={setHaptics} />
          </SettingsGroup>

          <SettingsGroup title="Gameplay">
            <SettingRow icon={<Icon.Hint s={18} c="#3a2a78" />} label="Auto-hints" sublabel="Glow tiles after 10s" value={hints} onChange={setHints} />
            <SettingPicker icon={<Icon.Globe s={18} c="#3a2a78" />} label="Language" value="🇬🇧 English" />
            <SettingPicker icon={<Icon.Grid s={18} c="#3a2a78" />} label="Default board" value="Classic 4×4" />
          </SettingsGroup>

          <SettingsGroup title="Look & Feel">
            <SettingRow icon={<span style={{ fontSize: 18 }}>🌙</span>} label="Dark mode" sublabel="Use system setting" value={dark} onChange={setDark} />
            <SettingPicker icon={<span style={{ fontSize: 18 }}>🎨</span>} label="Tile theme" value="Cream" />
            <SettingPicker icon={<span style={{ fontSize: 18 }}>🌅</span>} label="Background" value="Dawn" />
          </SettingsGroup>

          <SettingsGroup title="Account">
            <SettingPicker icon={<Icon.Heart s={18} c="#3a2a78" />} label="Restore purchases" value="" arrow />
            <SettingPicker icon={<Icon.Cog s={18} c="#3a2a78" />} label="Privacy" value="" arrow />
            <SettingPicker icon={<span style={{ fontSize: 18 }}>📜</span>} label="Terms of service" value="" arrow />
          </SettingsGroup>

          <div style={{ textAlign: 'center', marginTop: 18, fontFamily: 'Nunito', fontWeight: 700, fontSize: 11, color: 'rgba(58,42,120,0.55)' }}>
            Quibly v1.4.2 · made with 💜
          </div>
        </div>
      </DreamBackground>
    </div>
  );
}

function SettingsGroup({ title, children }) {
  return (
    <div style={{ marginTop: 16 }}>
      <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 13, color: 'rgba(255,255,255,0.95)', textShadow: '0 1px 0 rgba(80,50,160,0.4)', textTransform: 'uppercase', letterSpacing: 0.8, padding: '0 4px 6px' }}>{title}</div>
      <div className="q-card" style={{ borderRadius: 20, overflow: 'hidden' }}>
        {children}
      </div>
    </div>
  );
}

function SettingRow({ icon, label, sublabel, value, onChange }) {
  return (
    <div style={{ padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid rgba(80,50,160,0.08)' }}>
      <div style={{ width: 30, display: 'grid', placeItems: 'center' }}>{icon}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: 'Fredoka', fontWeight: 600, fontSize: 15, color: '#3a2a78' }}>{label}</div>
        {sublabel && <div style={{ fontFamily: 'Nunito', fontWeight: 600, fontSize: 11, color: 'rgba(58,42,120,0.65)' }}>{sublabel}</div>}
      </div>
      <button onClick={() => onChange(!value)} style={{
        border: 'none', cursor: 'pointer',
        width: 48, height: 28, borderRadius: 999,
        background: value ? 'linear-gradient(180deg,#8ee8ad,#36c071)' : 'rgba(80,50,160,0.18)',
        boxShadow: value ? 'inset 0 -2px 0 rgba(20,100,50,0.4), inset 0 1px 0 rgba(255,255,255,0.5)' : 'inset 0 1px 0 rgba(80,50,160,0.15)',
        position: 'relative', padding: 0, transition: 'all 200ms',
      }}>
        <div style={{
          position: 'absolute', top: 2, left: value ? 22 : 2,
          width: 24, height: 24, borderRadius: '50%',
          background: 'white', boxShadow: '0 2px 0 rgba(60,30,120,0.25)',
          transition: 'left 200ms cubic-bezier(.34,1.56,.64,1)',
        }} />
      </button>
    </div>
  );
}

function SettingPicker({ icon, label, value, arrow }) {
  return (
    <div style={{ padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 12, borderBottom: '1px solid rgba(80,50,160,0.08)' }}>
      <div style={{ width: 30, display: 'grid', placeItems: 'center' }}>{icon}</div>
      <div style={{ flex: 1, fontFamily: 'Fredoka', fontWeight: 600, fontSize: 15, color: '#3a2a78' }}>{label}</div>
      <div style={{ fontFamily: 'Fredoka', fontWeight: 500, fontSize: 14, color: 'rgba(58,42,120,0.7)', display: 'inline-flex', alignItems: 'center', gap: 4 }}>
        {value}
        <span style={{ opacity: 0.55 }}>›</span>
      </div>
    </div>
  );
}

window.ModesScreen = ModesScreen;
window.SettingsScreen = SettingsScreen;
